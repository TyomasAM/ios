#pragma once

// Pubg Mobile Battelgrounds (3.0.0 -- 64Bit) SDK Generate By @hhamk2
// Telegram Channel:- @SANSERO_MOD_1
// Generate on Mon Jan  8 10:14:17 2024
 
namespace SDK
{
//---------------------❣︎➪𝐒𝐀𝐍𝐒𝐄𝐑𝐎 𝐃𝐄𝐕𝐄𝐋𝐎𝐏𝐄𝐑༆✈︎🇪🇬---------------------------
//Script Structs
//---------------------❣︎➪𝐒𝐀𝐍𝐒𝐄𝐑𝐎 𝐃𝐄𝐕𝐄𝐋𝐎𝐏𝐄𝐑༆✈︎🇪🇬---------------------------

// UserDefinedStruct BP_STRUCT_WeaponBPTable_type.BP_STRUCT_WeaponBPTable_type
// 0x0058
struct FBP_STRUCT_WeaponBPTable_type
{
	struct FString                                     CName_0_CD600C314161E84152102388BAC2C6E5;                 // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     Path_1_4B3A115440CA4D3ED6BB1CAE5312F1D0;                  // 0x0010(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                ID_2_CE3ED80D47C51A8880AD2CBC79F2E6D0;                    // 0x0020(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0024(0x0004) MISSED OFFSET
	struct FString                                     Wrapper_3_1417B6C029873FAD0DDBA26505064332;               // 0x0028(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     LobbyPath_4_4623DFC03FE9DCA3544D323C06AB9278;             // 0x0038(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     WeaponClass_6_06A7B680656FDD4E11BFC0FA01E01EC3;           // 0x0048(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

}

