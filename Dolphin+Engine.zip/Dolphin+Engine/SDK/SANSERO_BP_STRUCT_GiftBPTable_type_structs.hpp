#pragma once

// Pubg Mobile Battelgrounds (3.0.0 -- 64Bit) SDK Generate By @hhamk2
// Telegram Channel:- @SANSERO_MOD_1
// Generate on Mon Jan  8 10:14:21 2024
 
namespace SDK
{
//---------------------❣︎➪𝐒𝐀𝐍𝐒𝐄𝐑𝐎 𝐃𝐄𝐕𝐄𝐋𝐎𝐏𝐄𝐑༆✈︎🇪🇬---------------------------
//Script Structs
//---------------------❣︎➪𝐒𝐀𝐍𝐒𝐄𝐑𝐎 𝐃𝐄𝐕𝐄𝐋𝐎𝐏𝐄𝐑༆✈︎🇪🇬---------------------------

// UserDefinedStruct BP_STRUCT_GiftBPTable_type.BP_STRUCT_GiftBPTable_type
// 0x0014
struct FBP_STRUCT_GiftBPTable_type
{
	struct FString                                     GiftAniPath_0_116612401D7ECFD72A9F4BCF0B4BFE88;           // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                ID_1_121869C02EC2913D7CAEEFD406BAD054;                    // 0x0010(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

}

