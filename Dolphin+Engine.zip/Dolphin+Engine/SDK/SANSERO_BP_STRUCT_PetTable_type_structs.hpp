#pragma once

// Pubg Mobile Battelgrounds (3.0.0 -- 64Bit) SDK Generate By @hhamk2
// Telegram Channel:- @SANSERO_MOD_1
// Generate on Mon Jan  8 10:14:20 2024
 
namespace SDK
{
//---------------------❣︎➪𝐒𝐀𝐍𝐒𝐄𝐑𝐎 𝐃𝐄𝐕𝐄𝐋𝐎𝐏𝐄𝐑༆✈︎🇪🇬---------------------------
//Script Structs
//---------------------❣︎➪𝐒𝐀𝐍𝐒𝐄𝐑𝐎 𝐃𝐄𝐕𝐄𝐋𝐎𝐏𝐄𝐑༆✈︎🇪🇬---------------------------

// UserDefinedStruct BP_STRUCT_PetTable_type.BP_STRUCT_PetTable_type
// 0x0140
struct FBP_STRUCT_PetTable_type
{
	int                                                FoodID2_0_74453B802213AE080C1CFB2A0F6CB952;               // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                PetID_1_161F774025C4024D0658398C0434C1E4;                 // 0x0004(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                FoodID3_3_74463BC02213AE090C1CFB2B0F6CB953;               // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                FoodID1_4_74443B402213AE070C1CFB290F6CB951;               // 0x000C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FString                                     PetName_5_0AD5B4406AF7C19B19AAA3EC04C27405;               // 0x0010(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                FoodCnt_6_0EBF950029CC741A0C1F016A0F6CBE74;               // 0x0020(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0024(0x0004) MISSED OFFSET
	struct FString                                     JumpUrl_7_78DA5D80770D0FB87D2AB07103CD68BC;               // 0x0028(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                JumpType_8_706CD94059C155B119B58A850CD70355;              // 0x0038(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                PetMaxLevel_12_15E11B803EA972342741D3080D060EBC;          // 0x003C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FString                                     PetImage_14_70AA6CC00734D40B21647D340C1D7495;             // 0x0040(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     ShareBgUrl_15_37E69D80203CAAA43B82F3630BDB729C;           // 0x0050(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                EatAction_16_62B7C7C01B6BC7AD350D95BE014E87DE;            // 0x0060(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x0064(0x0004) MISSED OFFSET
	struct FString                                     ClickAction_17_15DDFAC05B4516070D98AC880B568AFE;          // 0x0068(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                DefaultAction_18_336C92801D9FE2845525FDE600CF704E;        // 0x0078(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                OnlyPetCamera_22_7FA44EC046AEEDF36970978D00CEEE71;        // 0x007C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                PetAndAvatarCamera_23_070842C07D6093575B47E8000D58A301;   // 0x0080(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0x4];                                       // 0x0084(0x0004) MISSED OFFSET
	struct FString                                     BigIconForStore_26_19C65D801F69D0F214C8888304B43EC5;      // 0x0088(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     IconForStore_27_59F359001081BBCE1F89EEFB04A08715;         // 0x0098(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     PetMoodIds_28_69A63FC05650597524C5E6360126C393;           // 0x00A8(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     PetActionPath_29_6581EEC061F1369711F2C3050CA22638;        // 0x00B8(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     PetClothPath_30_675355C07747DC3F23E0C98805E173D8;         // 0x00C8(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     PetPath_31_4674174057A3B9CB1992038B04C05C98;              // 0x00D8(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     PortraitImage_32_418517C028D44DEF7496DBBD05F0BB85;        // 0x00E8(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     IndiaShareBgUrl_33_7C3196C0049B6CBF4668FB770B5A7C4C;      // 0x00F8(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     PetLevelUpImage_34_2AF55C0015DCFB987645CA990E573705;      // 0x0108(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     BrandLogo_35_2AC407C02A97A7655B4107090F7D1E5F;            // 0x0118(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                IgnoreUnlock_36_53D7FDC038CA15975236FDA9087BD05B;         // 0x0128(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData03[0x4];                                       // 0x012C(0x0004) MISSED OFFSET
	struct FString                                     PetResHandlePath_37_1E7414C03C0BE9C3655D8C4B02AEC4E8;     // 0x0130(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

}

