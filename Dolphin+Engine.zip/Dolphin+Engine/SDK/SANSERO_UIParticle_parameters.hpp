#pragma once

// Pubg Mobile Battelgrounds (3.0.0 -- 64Bit) SDK Generate By @hhamk2
// Telegram Channel:- @SANSERO_MOD_1
// Generate on Mon Jan  8 10:14:13 2024
 
#include "../SDK.hpp"

namespace SDK
{
//---------------------❣︎➪𝐒𝐀𝐍𝐒𝐄𝐑𝐎 𝐃𝐄𝐕𝐄𝐋𝐎𝐏𝐄𝐑༆✈︎🇪🇬---------------------------
//Parameters
//---------------------❣︎➪𝐒𝐀𝐍𝐒𝐄𝐑𝐎 𝐃𝐄𝐕𝐄𝐋𝐎𝐏𝐄𝐑༆✈︎🇪🇬---------------------------

// Function UIParticle.UIParticle.StopEmit
struct UUIParticle_StopEmit_Params
{
};

// Function UIParticle.UIParticle.Stop
struct UUIParticle_Stop_Params
{
};

// Function UIParticle.UIParticle.SetPlayParticle
struct UUIParticle_SetPlayParticle_Params
{
	bool                                               InPlayParticle;                                           // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function UIParticle.UIParticle.Play
struct UUIParticle_Play_Params
{
};

// Function UIParticle.UIParticleEmitter.StopEmit
struct UUIParticleEmitter_StopEmit_Params
{
};

// Function UIParticle.UIParticleEmitter.Stop
struct UUIParticleEmitter_Stop_Params
{
};

// Function UIParticle.UIParticleEmitter.SetPlayParticle
struct UUIParticleEmitter_SetPlayParticle_Params
{
	bool                                               InPlayParticle;                                           // (Parm, ZeroConstructor, IsPlainOldData)
};

// Function UIParticle.UIParticleEmitter.Play
struct UUIParticleEmitter_Play_Params
{
};

}

