#pragma once

// Pubg Mobile Battelgrounds (3.0.0 -- 64Bit) SDK Generate By @hhamk2
// Telegram Channel:- @SANSERO_MOD_1
// Generate on Mon Jan  8 10:14:21 2024
 
namespace SDK
{
//---------------------❣︎➪𝐒𝐀𝐍𝐒𝐄𝐑𝐎 𝐃𝐄𝐕𝐄𝐋𝐎𝐏𝐄𝐑༆✈︎🇪🇬---------------------------
//Script Structs
//---------------------❣︎➪𝐒𝐀𝐍𝐒𝐄𝐑𝐎 𝐃𝐄𝐕𝐄𝐋𝐎𝐏𝐄𝐑༆✈︎🇪🇬---------------------------

// UserDefinedStruct BP_STRUCT_RareItemCfg_type.BP_STRUCT_RareItemCfg_type
// 0x0040
struct FBP_STRUCT_RareItemCfg_type
{
	int                                                ItemId_0_55BFBEC07701C41544D45E42080B2824;                // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0004(0x0004) MISSED OFFSET
	struct FString                                     Path_1_7CF17300760414C62D59F2D009D66908;                  // 0x0008(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                RareType_2_23881AC04B9D705F2709505A092376E5;              // 0x0018(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x001C(0x0004) MISSED OFFSET
	struct FString                                     PathIcon_4_38B2D5406371AFD77F54A0AF0905303E;              // 0x0020(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     CornerPath_5_01B30D403311FBA129EBCE9E0D10CF98;            // 0x0030(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

}

