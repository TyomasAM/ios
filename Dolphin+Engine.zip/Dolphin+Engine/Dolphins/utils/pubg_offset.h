//
// Created by XBK on 2022/1/16.
//
namespace PubgOffset {
//Class: World.Object下的
//NetDriver* NetDriver;

//NetConnection* ServerConnection;

//Class: Player.Object下的
//PlayerController* PlayerController;
int PlayerControllerOffset[3] = {0x38, 0x78, 0x30};
namespace PlayerControllerParam {
//STExtraBaseCharacter* STExtraBaseCharacter;
int SelfOffset = 0x2528;//0x24a0//0x24d0
//Class: Controller.Actor.Object下的
//Rotator ControlRotation;
int MouseOffset = 0x428;//0x420
//PlayerCameraManager* PlayerCameraManager;
int CameraManagerOffset = 0x490;//0x488
namespace CameraManagerParam{
//TViewTarget ViewTarget;
int PovOffset = 0xfd0 + 0x10;//0xfC0
}
namespace ControllerFunction {

int LineOfSightToOffset = 0x750;//掩体不知道0x748
}
}
//ULevel* PersistentLevel;
int ULevelOffset = 0x30;//uLevel
namespace ULevelParam {
//AActor* ObserveTarget;
int ObjectArrayOffset = 0xA0;//数组
//int MaxPacket;
int ObjectCountOffset = 0xA8;//成员数量
}

namespace ObjectParam {
int ClassIdOffset = 0x18;//类型ID
int ClassNameOffset = 0xC;//类名偏移

namespace PlayerFunction {
//int AddControllerYawInputOffset = 0x828;//ExitShovelingTPPFovChangeSpeed;不知道
//int AddControllerRollInputOffset = 0x820;//ShovelingTPPFovVaule;不知道
//int AddControllerPitchInputOffset = 0x830;//ShovelingLegStartFollowBodyMinAngle;不知道

int AddControllerYawInputOffset = 0x828 + 0x8;
int AddControllerRollInputOffset = 0x820 + 0x8;
int AddControllerPitchInputOffset = 0x830 + 0x8;
}
//以前是PawnStateRepSyncData PawnStateRepSyncData;，现在可能是uint64 CurrentStates;
int StatusOffset = 0xf28;//人物状态0xee0//0xee8
//类 Class: UAECharacter.Character.Pawn.Actor.Object
//    或者
//类 struct AUAECharacter : ACharacter
//int TeamID;
int TeamOffset = 0x8f0;//人物队伍ID 0x8f8
//类 Class: UAECharacter.Character.Pawn.Actor.Object
//    或者
//类 struct AUAECharacter : ACharacter
//FString PlayerName; 上一个是 FName PlayerType;
int NameOffset = 0x8a8;//人物名字
//Class: UAECharacter.Character.Pawn.Actor.Object
//bool bIsAI;
int RobotOffset = 0x9a1;//人物人机判断//0x990
//Class: STExtraCharacter.UAECharacter.Character.Pawn.Actor.Object
//float Health;
int HpOffset = 0xd58;
int Dead = 0xd74;
//人物血量 0xd08//0xd18
//以前是STCharacterMovementComponent* STCharacterMovement;
//代表运动复制运动；
//RepMovement ReplicatedMovement;可能是
int MoveCoordOffset = 0xb0;//人物移动坐标

//Class: Character.Pawn.Actor.Object
    //或者
    //类struct AWheeledVehicle : APawn
//SkeletalMeshComponent* Mesh;
int MeshOffset = 0x458;//人物骨骼列阵0x450
namespace MeshParam{
//类 struct UCharacterMovementComponent : UPawnMovementComponent
//Class: CharacterMovementComponent.PawnMovementComponent.NavMovementComponent.MovementComponent.ActorComponent.Object
//Character* CharacterOwner;
int HumanOffset = 0x1A4 + 0xC;//人物骨骼基矩阵
//类 UStaticMeshComponent : UMeshComponent
//Class: StaticMeshComponent.MeshComponent.PrimitiveComponent.SceneComponent.ActorComponent.Object
//StaticMesh* StaticMesh;
int BonesOffset = 0x810;//人物骨骼0x7a0
}
//bool bIsWeaponFiring;
int OpenFireOffset = 0x15c0;//开火0x1538//0x1560
//bool bIsGunADS;可能是
int OpenTheSightOffset = 0xFE9;//开镜0xf91//0xfa9
//AnimStatusKeyList LastUpdateStatusKeyList;可能是
int WeaponOneOffset = 0x26c0 + 0x20;//人物手持武器0x24b8//0x25c0
namespace WeaponParam{
int MasterOffset = 0xB0;//枪械主人
//byte ShootMode;
int ShootModeOffset = 0xeb0;//武器射击模式0xe94
//ShootWeaponEntity* ShootWeaponEntityComp;可能是
int WeaponAttrOffset = 0xFD8;//武器属性0xfb8
namespace WeaponAttrParam{
//float BulletFireSpeed;
int BulletSpeedOffset = 0x4f0;//武器子弹速度//0x4e0
//float RecoilKickADS;
int RecoilOffset = 0xc50;//武器后坐力
}
}
//Class: PickUpListWrapperActor.PickUpWrapperActor.UAENetActor.LuaActor.Actor.Object
//    PickUpItemData[] PickUpDataList;
int GoodsListOffset = 0x848;//盒子物资0x848
namespace GoodsListParam {
int DataBase = 0x38;
}
//SceneComponent* RootComponent
int CoordOffset = 0x1b0;//对象坐标0x1a8
namespace CoordParam {
int HeightOffset = 0x17c;//对象高度 可用性未知
int CoordOffset = 0x184;//对象坐标 xyzCurveVector* CurveForRootScale;
}
}
}
